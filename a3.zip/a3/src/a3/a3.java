package a3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class a3 {
	public static void main(String[] args) {
		//Formating is host:port/dbname, username, password
		try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5433/postgres", "postgres", "password")) {
			
            System.out.println("Connected to PostgreSQL database!");
            
            Scanner scan = new Scanner(System.in);
            Statement statement = connection.createStatement();
            
            //uncomment this if it crashes, it needs to delete the table to create a fresh one
            //normally it clears when exiting the program, however when crashing it doesn't do this
            //so a manual reset is necessary
            
            //statement.executeUpdate("DROP TABLE students");
            
            //Makes and fills in a table with default values
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS students("
            		+ "student_id SERIAL PRIMARY KEY,"
            		+ "first_name TEXT NOT NULL,"
            		+ "last_name TEXT NOT NULL,"
            		+ "email TEXT UNIQUE NOT NULL,"
            		+ "enrollment_date DATE)");
            
            statement.executeUpdate("INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES"
            		+ "('John', 'Doe', 'john.doe@example.com', '2023-09-01'),"
            		+ "('Jane', 'Smith', 'jane.smith@example.com', '2023-09-01'),"
            		+ "('Jim', 'Beam', 'jim.beam@example.com', '2023-09-02')");
            
            String input;
            
            //Input loop
            while (true) {
            	//Prompt for user input
            	System.out.print("\n");
            	System.out.print("0.) getAllStudents()\n1.) addStudent()\n2.) updateStudentEmail\n3.) deleteStudent()\n4.) exitProgram()\n\n");
            	input = scan.nextLine();
            	System.out.print("\n");
            	
            	//Check what the user input
            	if (input.equals("0")) {
            		//Print out all students and their data
                    ResultSet resultSet = statement.executeQuery("SELECT * FROM students");
                    while (resultSet.next()) {
                        System.out.print(resultSet.getString("student_id") + " " + resultSet.getString("first_name") + " " + resultSet.getString("last_name") + " " + resultSet.getString("email") + " " + resultSet.getString("enrollment_date") + "\n");
                    }
            	}
            	else if (input.equals("1")) {
            		//Add student
            		System.out.print("Enter first name:\n\n");
            		String first = scan.nextLine();
            		System.out.print("\nEnter last name:\n\n");
            		String last = scan.nextLine();
            		System.out.print("\nEnter email:\n\n");
            		String email = scan.nextLine();
            		System.out.print("\nEnter enrollment date:\n\n");
            		input = scan.nextLine();
            		statement.executeUpdate("INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES"
            				+ "('"+first+"', '"+last+"', '"+email+"', '"+input+"');");
            	}
            	else if (input.equals("2")) {
            		//Change email
            		System.out.print("Enter student id:\n\n");
            		String id = scan.nextLine();
            		System.out.print("\nEnter new email:\n\n");
            		input = scan.nextLine();
            		statement.executeUpdate("UPDATE students SET email='"+input+"' WHERE student_id="+id+";");
            	}
            	else if (input.equals("3")) {
            		//Delete student
            		System.out.print("Enter student id:\n");
            		input = scan.nextLine();
            		statement.executeUpdate("DELETE FROM students WHERE student_id='"+input+"';");
            	}
            	else if (input.equals("4")) {
            		//Exit program
            		System.out.print("Exiting Program");
            		break;
            	}
            	else {
            		//Not a valid input when choosing options
            		System.out.print("Please enter a valid input\n");
            	}
            }
            //Drop table when done so that a fresh one is made when starting the program
            statement.executeUpdate("DROP TABLE students");
            scan.close();
        }
		catch (SQLException e) {
            System.out.println("Connection failure.");
            e.printStackTrace();
        }
	}
}
